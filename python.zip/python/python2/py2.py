sum=0
# for n in range(5):
#  a=(int(input("entre value for sum")))
#  sum+=a

# print(sum)

while(sum < 20):
 a=(int(input("entre value for sum")))
 sum+=a

print(sum) 