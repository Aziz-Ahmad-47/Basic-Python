sum=0
for n in range(5):
    a=(int(input('enter the value for a ')))  
    sum=sum+a
print(sum)