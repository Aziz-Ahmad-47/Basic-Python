
a=int(input("enter value for a"))
b=int(input("enter value for a"))
print(a+b)
