import sqlite3
con=sqlite3.connect("sqlite2.db")
con.execute(
    '''
    CREATE TABLE IF NOT EXISTS tb1(
      st_id int an auto primary key,
      st_name VARCHAR(10),
      st_rollno VARCHAR(30),
      st_class VARCHAR(30)
    ); '''
)

data=" INSERT INTO tb1(st_id,st_name,st_rollno,st_class) VALUES('1','aziz','47','BSSE')"
data=" INSERT INTO tb1(st_id,st_name,st_rollno,st_class) VALUES('2','ahmad','47','BSSE')"
data=" INSERT INTO tb1(st_id,st_name,st_rollno,st_class) VALUES('3','khasman','47','BSSE')"
data=" INSERT INTO tb1(st_id,st_name,st_rollno,st_class) VALUES('4','apo','47','BSSE')"
con.execute(data)
con.commit()
con.close()