w = 'pakistan is my country'
n=len(w)
for n in range(0,n+1):
    print(n)
    print(w[n])