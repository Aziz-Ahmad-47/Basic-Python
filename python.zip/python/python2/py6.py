a= input(''' press
     1 for show all data
     2 for inser data
     3 for upadate tabel
     4 for delete data
     5 exit
    ''')
import sqlite3

conn = sqlite3.connect("sqlite3.db")
while True:
  if a==1:
   info=conn.execute("SELECT * FROM tb2")
   for a in info:
      print(a)
   conn.commit()
  
  elif a==2:
     data = "INSERT INTO tb2(ab_id, ab_name, ab_address, ab_city) values('5','ali','gulapur','chamogard')"
     conn.execute(data)
     conn.commit()
  elif a==3:
     conn.execute('''
     update tb2 set ab_city = 'rama' where ab_id=4
    ''')
  elif a==4:
   conn.commit()
   st_id=input("enter id for delte")
   conn.execute("DELETE FROM tb2 where ab_id="+st_id)
   conn.commit()
  else:
    break;
  conn.close()